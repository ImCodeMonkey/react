import React from "react"

//我们定义一个App的组件，在HTML中可以用<App></App>来使用
//React要求自定义组件必须是大写开头
//React要求自定义组件的类必须继承与React.Component类
class App extends React.Component{
	//此处可以定义函数
	list(cla){
		if(cla == '篮球'){
			return (
				<ul>
					<li>乔丹</li>
					<li>奥尼尔</li>
				</ul>
			)
		}else if(cla == '足球'){
			return (
				<ul>
					<li>贝克汉姆</li>
					<li>C罗</li>
				</ul>
			)
		}
	}
	
	//组件中最重要的方式是render方法，render是渲染的意思
	render(){
		//定义一个数组
		let arr = ['白板','幺鸡','二条','三饼'].map((item,index)=>{
			return <li key={index}>{item}</li>
		})
		//此处可以定义函数 基本不会这样写
//		let lists = function(){
//			return (
//				<ul>
//					<li>list1</li>
//					<li>list2</li>
//					<li>list3</li>
//					<li>list4</li>
//				</ul>
//			)
//		}
		//反回一个jsx语法
		return (
			<div>
				<h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>
				<h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>
				<img src="" />
				<div className="box">
					{3 > 8? "A" : "B"}
					<h2>jsx可以调用函数</h2>
					{this.list('足球')}
					{/*注释*{lists()}**/}
				</div>
				<h3>jsx可以设置样式</h3>
				<div style={{"width":"100px","height":"100px","float":"left","background":"red"}}></div>
				<ul style={{'clear':'both'}}>
					{arr}
				</ul>
			</div>
		);
	}
}

//向外暴露
export default App;


//上面的程序也可以这样写

//import React,{Component} from "react"
//
//class App extends Component{
//	render(){
//		return <h1>你好我是react,很高兴 遇见你!</h1>;
//	}
//}
//
//export default App;