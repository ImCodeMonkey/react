#react 的配置与hellow world

react中使用的是JSX语法，这是一种可以将HTML和JS揉着写的语法糖。
但是浏览器不能直接识别JSX语法，所以我们需要babel来翻译
既然用了babel，那我们就可以写es6语法了
写一点翻译一点很不方便，所以要用webpack结合bable-loader来watch文件
既然用了webpack，那就可以用模块化开发了。

react经典配置     webpack + bable + bable-loader + ES6 + react



我们创建一个项目文件夹helloworld，在这个文件夹中，配置webpack + babel环境，让webpack可以指导bable翻译ES6语法



创建package.json
npm init

安装webpack
首先要全局安装webpack
npm install webpack -g
安装webpack作为项目依赖
npm install --save-dev webpack

我们创建一个webpack.config.js文件，这个文件是webpack的配置文件
参考官方文档https://webpack.js.org/configuration/ 创建配置文件
至此webpack就可以进行标准的cmd模块化开发了


安装bable-loader去翻译es6
npm install --save-dev babel-loader
npm install --save-dev babel-core  
npm install --save-dev babel-preset-es2015

bable官网   https://www.npmjs.com/package/babel-loader
在webpack.config.js 文件中加入以下内容

module: {
	rules: [{
		test: /\.js$/,
		exclude: /(node_modules|bower_components)/,
		use: {
			loader: 'babel-loader',
			options: {
				presets: ['es2015']
			}
		}
	}]
}

此时运行webpack命令将自动使用cmd构建app文件下的main.js，并且使用babel翻译。

下面配置react
npm install --save-dev react
npm install --save-dev react-dom
npm install --save-dev babel-cli babel-preset-react
1.react为什么不是bower来安装，而是npm安装
2.为什么是save-dev而不是save，也就是说为什么是开发依赖而不是运行依赖

改变webpack.config.js文件增加一个presets的配置项,并配置自动监听
module: {
	rules: [{
		test: /\.js$/,
		exclude: /(node_modules|bower_components)/,
		use: {
			loader: 'babel-loader',
			options: {
				presets: ['es2015','react']
			}
		}
	}]
}，
watch:true

至此已经配置完毕react起步的所有依赖


#####hellow world
创建app/App.js文件这是一个组件：

import React from "react"

//我们定义一个App的组件，在HTML中可以用<App></App>来使用
//React要求自定义组件必须是大写开头
//React要求自定义组件的类必须继承与React.Component类
class App extends React.Component{
	//组件中最重要的方式是render方法，render是渲染的意思
	render(){
		//反回一个jsx语法
		return <h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>;
	}
}

//向外暴露
export default App;


下面我们要使用这个App组件，所以我们来到main.js这个文件
import React from "react";
import {render} from "react-dom";
//引入我们编写的组件
import App from "./App.js";


//使用、挂载组件，两个参数
//第一个参数是jsx语法
//第二个参数标识这个组件挂在哪里
render(
	<App></App> ,
	document.getElementById("app-contain")
)


###简单介绍jsx语法糖
jsx不能直接运行，是被bable-loader中的react这个preset翻译的

需要注意：
1.必须被一个单独的大元素包裹，比如div或者section
	应该是被一个div包裹起来
	return (
			<div>
				<h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>
				<h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>
			</div>
		);
2.标签必须封闭
	return (
			<div>
				<h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>
				<h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>
				<img src="" />
			</div>
		);
3.class要写成className   for要写成htmlFor
<div className="box"></div>
4.HTML注释不能使用必须使用js注释
5.jsx中可以使用{}标识临时插入一个js简单表达式，不能使if、for等复杂结构语句，可以使&&  ||   短路语法，可以是？三元运算符，可以调用函数
6.原生标签比如p li div如果要使用自定义属性必须用data-前缀
	<p data-a="10"></p>
如果是自定义标签，可以随便传属性
7.jsx表达式用{}包裹，   在JSX中不能使用if else语句，但可以使用三元运算表达式来替代
8.可以运行函数
	class App extends React.Component{
		//此处可以定义函数
		list(){
			return (
				<ul>
					<li>list1</li>
					<li>list2</li>
					<li>list3</li>
					<li>list4</li>
				</ul>
			)
		}
		
		//组件中最重要的方式是render方法，render是渲染的意思
		render(){
			//此处可以定义函数
			let lists = function(){
				return (
					<ul>
						<li>list1</li>
						<li>list2</li>
						<li>list3</li>
						<li>list4</li>
					</ul>
				)
			}
			//反回一个jsx语法
			return (
				<div>
					<h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>
					<h1>你好我是react,很高兴 遇见你!说{5000*2}次我爱你</h1>
					<img src="" />
					<div className="box">
						{3 > 8? "A" : "B"}
						{this.list()}
						{lists()}
					</div>
				</div>
			);
		}
	}
9.jsx可以设置样式，使用{{}}
	<div style={{"width":"100px","height":"100px","float":"left","background":"red"}}></div>
10.自动展开数组（只有dom元素数组才可以）
	可以使用数组，如果数组中使用的是jsx语法，数组会被自动展开，所以不需要使用ng-repeat这样的指令展开数组。
	//定义一个数组，只要是重复的数组，必须有key属性
	let arr = ['白板','幺鸡','二条','三饼'].map((item,index)=>{
		return <li key={index}>{item}</li>
	})
	<ul style={{'clear':'both'}}>
		{arr}
	</ul>
