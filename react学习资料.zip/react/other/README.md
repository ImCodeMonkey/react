#其他API

##无状态组件
当我们现在的组件仅仅是为了呈递一些DOM元素，没有state、props等东西，此时可以不用费劲
class My extends React.Component{}
而是一个简单的函数即可
import React from "react";

export default ()=>{
	return (
		<div>
			<h1>我是My组件</h1>
		</div>
	)
}

此时真的可以用它
