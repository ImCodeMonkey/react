import React from "react";

class My extends React.Component{
	constructor(){
		super();
		this.state = {
			islike : true
		}
		
		this.clickHandler = (this.clickHandler).bind(this);
	}
	
	clickHandler(){
		this.setState({islike : !this.state.islike})
		console.log(this.state.islike);
	}
	
	render(){
		return (
			<div>
				<h1 onClick={this.clickHandler}>你{this.state.islike ? "喜欢" : "不喜欢"}我</h1>
			</div>
		)
	}
}

//向外暴露
export default My;
