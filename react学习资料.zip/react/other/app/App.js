import React from "react";
import My from "./My";

class App extends React.Component {

	//构造函数
	constructor() {
		super();
	}

	render() {
		return(
			<div>
				<My></My>
			</div>
		);
	}
}

export default App;