#react 中的数据传递
react中和数据有关系的有   state、props、context


##组件自己身上的属性
我们可以在组件的类定义里面写constructor构造器，里面定义this.a = 100.表示给组件的实例绑定一个a属性，值是100，要求必须调用susper
在jsx中使用的时候，直接{this.a}即可


我们增加一个按钮可以试着让客户点击的时候值进行变化
	class App extends React.Component{
		
		//构造函数
		constructor(){
			super();//要求调用super
			this.a = 100;
		}
		
		add(){
			this.a++
		}
		
		render(){
			return (
				<div>
					<p>
						{this.a}
					</p>
					<p>
						<input type="button" value='按我' onClick={(this.add).bind(this)} />
					</p>
				</div>
			);
		}
	}
通过案例学习了
	1.绑定监听使用onClick onMousedowm onMouseenter onBlur,吧on后面的字母大写，react会自动识别react事件
	2.绑定函数的时候，this上下文是有问题的，所以需要使用bind（）方法来设置上下文
	3.绑定监听函数的时候，注意使用{}而不是""
		<input type="button" value='按我' onClick={(this.add).bind(this)} />
	
所以在reavt中，组件自己的属性的变化不会引发视图的变化
闭包中的值变化也不会引起视图的改变

正确解决方法
state方式
	class App extends React.Component{
		
		//构造函数
		constructor(){
			super();//要求调用super
			this.state={
				a : 100
			}
		}
		
		add(){
			this.setState({a: this.state.a + 1})
		}
	
		render(){
			return (
				<div>
					<h1>我是app组件</h1>
					<p>我有状态教state</p>
					<p>
						{this.state.a}
					</p>
					<p>
						<input type='button' value="按我" onClick={(this.add).bind(this)} />
					</p>
				</div>
			);
		}
	}
	
只有更新 state、props、context才会引发视图的改变，从而改变DOM
定义state： 在构造函数中使用this.state属性即可
使用state： 在jsx中{this.state.a}
改变state: this.setState({a:this.state.a + 1}); 不能写++，因为state的属性只读


state是内部的（所以也叫local state），只有组件自己能改变自己的state，别人想改变自己的state，都不可能

后面介绍redux架构，所有组件自己的state越来月少用了，而是变成了redux自己的state
