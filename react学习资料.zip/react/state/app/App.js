import React from "react"

class App extends React.Component{
	
	//构造函数
	constructor(){
		super();//要求调用super
		this.state={
			a : 100
		}
	}
	
	add(){
		this.setState({a: this.state.a + 1})
	}

	render(){
		return (
			<div>
				<h1>我是app组件</h1>
				<p>我有状态教state</p>
				<p>
					{this.state.a}
				</p>
				<p>
					<input type='button' value="按我" onClick={(this.add).bind(this)} />
				</p>
			</div>
		);
	}
}

export default App;
