##context

上下文的精髓是可以跨级传递数据，爷爷组件可以直接传递数据到孙子组件

app/yeye.js

import React from "react";
import Baba from "./Baba";
import PropTypes from "prop-types";

class Yeye extends React.Component {

	//构造函数
	constructor(props) {
		super();
		this.state = {
			a : 100
		}
	}
	//得到孩子上下文，实际上这里表示一种设置
	getChildContext(){
		return {
			a : this.state.a
		}
	}
	
	render() {
		return(
			<div>
				<h1>爷爷</h1>
				<Baba></Baba>
			</div>
		);
	}
}

Yeye.childContextTypes = {
	a : PropTypes.number.isRequired
}

export default Yeye;

app/baba.js

import React from "react";
import Sunzi from "./Sunzi";
import PropTypes from "prop-types";

class Baba extends React.Component {

	//构造函数
	constructor(props,context) {
		super();
		console.log(context);
	}

	render() {
		return(
			<div>
				<h1>爸爸</h1>
				<Sunzi></Sunzi>
			</div>
		);
	}
}

Baba.contextTypes = {
	a : PropTypes.number
}

export default Baba;

app/sunzi.js

import React from "react";
import PropTypes from "prop-types";

class Sunzi extends React.Component {

	//构造函数
	constructor(props,context) {
		super();
		console.log(context);
	}

	render() {
		return(
			<div>
				<h1>孙子</h1>
			</div>
		);
	}
}

Sunzi.contextTypes = {
	a : PropTypes.number
}

export default Sunzi;



结论：
1. 当祖先元素中更改了上下文的数据，此时所有的子孙元素中的数据都会更改，视图也会更新。
2. 反之不成立，可以认为上下文的数据在子孙元素中是制度的，此时又需要使用奇淫技巧，就是在context中共享一个操作祖先元素的函数，子孙元素通过上下文得到这个函数，从未操作祖先元素。
也就是说state是自治的，不涉及传值的事情，props是单项的，只能父亲到儿子，context也是单项的，祖先到后代，如果要反向，就要传入一个函数。

context 很少用  传值基本上用props。 除非特别深的跨级别传值，可以用context


