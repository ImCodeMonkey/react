import React from "react";
import Baba from "./Baba";
import PropTypes from "prop-types";

class Yeye extends React.Component {

	//构造函数
	constructor(props) {
		super();
		this.state = {
			a : 100
		}
	}
	//设置自己的A值，这个函数要进入上下问的通道中
	addA(number){
		this.setState({a : this.state.a + 1})
	}
	
	//得到孩子上下文，实际上这里表示一种设置,反回一个对象，这个对象就是现在这个家族体系共享的上下文，将上下文中的a值变为自己状态中的a值
	getChildContext(){
		return {
			a : this.state.a,
			addA : (this.addA).bind(this)
		}
	}
	
	render() {
		return(
			<div>
				<h1>
					爷爷{this.state.a}
					<input type="button" value="按我" onClick={()=>{this.setState({a:this.state.a + 1})}} />
				</h1>
				<Baba></Baba>
			</div>
		);
	}
}

//设置child的上下文类型
Yeye.childContextTypes = {
	a : PropTypes.number.isRequired,
	addA : PropTypes.func.isRequired
}

export default Yeye;