import React from "react";
import Yeye from "./Yeye.js";

class App extends React.Component {

	//构造函数
	constructor() {
		super();

		this.state = {
			d: 16
		}
	}

	render() {
		return(
			<div>
				<Yeye><Yeye/>
			</div>
		);
	}
}

export default App;