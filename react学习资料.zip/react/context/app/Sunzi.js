import React from "react";
import PropTypes from "prop-types";

class Sunzi extends React.Component {

	//构造函数
	constructor(props,context) {
		super();
		console.log(context);
	}

	render() {
		return(
			<div>
				<h1>孙子{this.context.a}</h1>
				<input type="button" value="按我" onClick={()=>{this.context.addA()}} />
			</div>
		);
	}
}

Sunzi.contextTypes = {
	a : PropTypes.number,
	addA : PropTypes.func
}

export default Sunzi;