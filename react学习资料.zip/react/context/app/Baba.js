import React from "react";
import Sunzi from "./Sunzi";
import PropTypes from "prop-types";

class Baba extends React.Component {

	//构造函数
	constructor(props,context) {
		super();
		console.log(context);
		this.state = {
			d: context
		}
	}

	render() {
		return(
			<div>
				<h1>爸爸{this.state.d}</h1>
				<Sunzi></Sunzi>
			</div>
		);
	}
}

Baba.contextTypes = {
	a : PropTypes.number
}

export default Baba;