import React from "react";
import { PropTypes } from "prop-types";

class MyCompo extends React.Component {

	//构造函数
	constructor(props) {
		super();
	}

	render() {
		return(
			<div>
				456
			</div>
		);
	}
}

//定义组件需要传入的参数
//MyCompo.propTypes = {
//	a: PropTypes.string.isRequired,
//	b: PropTypes.string.isRequired,
//	c: PropTypes.number.isRequired
//}

export default MyCompo;