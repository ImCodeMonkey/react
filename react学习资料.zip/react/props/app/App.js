import React from "react";
import MyCompo from "./MyCompo.js";

class App extends React.Component {

	//构造函数
	constructor() {
		super();

		this.state = {
			d: 16
		}
	}

	setD(number) {
		this.setState({
			"d": number
		});
	}

	render() {
		return(
			<div>
				<h1>我是APP组件,我有一个d状态:{this.state.d}</h1>
				<MyCompo setD={(this.setD).bind(this)} d={this.state.d}></MyCompo>
			</div>
		);
	}
}

export default App;