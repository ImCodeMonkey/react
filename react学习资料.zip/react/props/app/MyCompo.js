import React from "react";
import { PropTypes } from "prop-types";

class MyCompo extends React.Component {

	//构造函数
	constructor(props) {
		super();

		this.state = {
			d: props.d
		}

		this.add = () => {
			this.setState({
				"d": this.state.d + 1
			});
			props.setD(this.state.d + 1);
		}
	}

	render() {
		return(
			<div>
				<hr/>
				我是MyCompo
				<p>{this.state.d}</p>
				<p>
					<input type="button" value="按我更改d的值" onClick={this.add} />
				</p>
			</div>
		);
	}
}

//定义组件需要传入的参数
//MyCompo.propTypes = {
//	a: PropTypes.string.isRequired,
//	b: PropTypes.string.isRequired,
//	c: PropTypes.number.isRequired
//}

export default MyCompo;