props方式
就是定义在自定义自建标签上面的值，就是props。当props改变的时候，会引发视图的重绘

如果父组件想向MyCompo传输数据使用属性：
class App extends React.Component{
	
	//构造函数
	constructor(){
		super()
	}

	render(){
		return (
			<div>
				<MyCompo a="66" b="77" c="88"></MyCompo>
			</div>
		);
	}
}

注意，子组件中不允许改变父组件中传输的属性
子组件MyCompo中可以无脑使用this.props来枚举传入的属性
class MyCompo extends React.Component{
	
	//构造函数
	constructor(){
		super()
	}

	render(){
		return (
			<div>
				我是MyCompo
				<p>{this.props.a}</p>
				<p>{this.props.b}</p>
				<p>{this.props.c}</p>
			</div>
		);
	}
}

如果需要在构造函数中使用这个值,此时系统会将props座位构造函数的第一个参数传入
class MyCompo extends React.Component{
	constructor(props,context){
		super();
		this.state={
			c:props.c
		}
	}
}

在子组件中props是只读的，不能修改props的值，如果想修改可以
class MyCompo extends React.Component{
	constructor(props,context){
		super();
		this.state={
			c:props.c
		}
	}
}

props属性可以被验证有效性
npm install --save-dev prop-types

import {PropTypes} from "prop-types";

//定义组件需要传入的参数
//类名.propTypes 值是一个JSON。key就是需要传进来的props属性名，v就是对他的限制
MyCompo.propTypes = {
	a : PropTypes.string.isRequired,  //定义a属性是一个字符串，必传
	b : PropTypes.string,      //b属性是一个字符串，不必传
	c : PropTypes.number.isRequired
}


//子组件要把数据返回给父组件（父组件通过传函数给子组件，子组件通过传参数把数据反回父组件，父组件的函数接受参数改变父组件的state等值）



父组件APP现在想让子组件MyCompo设置App自己的state.d值，此时就需要传入d值，并且传入一个设置d值得函数到子组件：

app/app.js

import React from "react";
import MyCompo from "./MyCompo.js";

class App extends React.Component{
	
	//构造函数
	constructor(){
		super();
		
		this.state = {
			d : 16
		}
	}
	
	setD(number){
		this.setState({"d" : number});
	}
	
	render(){
		return (
			<div>
				<h1>我是APP组件,我有一个d状态:{this.state.d}</h1>
				<MyCompo setD={(this.setD).bind(this)} d={this.state.d}></MyCompo>
			</div>
		);
	}
}

export default App;

子组件要接受父组件传来的d参数和设置D的函数：
class MyCompo extends React.Component {

	//构造函数
	constructor(props) {
		super();

		this.state = {
			d: props.d
		}

		this.add = () => {
			this.setState({
				"d": this.state.d + 1
			});
			props.setD(this.state.d + 1);
		}
	}

	render() {
		return(
			<div>
				<hr/>
				我是MyCompo
				<p>{this.state.d}</p>
				<p>
					<input type="button" value="按我更改d的值" onClick={this.add} />
				</p>
			</div>
		);
	}
}


react 是一个特别简单的框架，没有angular中directive中的scope @ = &等等符号都没有
数据的单项传递是react的精髓